package com.wclark7.EldieApi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EldieApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(EldieApiApplication.class, args);
	}

}
